package com.example.demo.javakod;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Igrac {

	private String ime, prezime;
	private String pozicija;
	private ArrayList<StatistickeKategorije> listaSKategorija;
	private StatistickeKategorije proseciSKategorija;
	private long brojacMeceva;
	private GotovIgrac gotovIgrac;
	// private static ArrayList<GotovIgrac> listaGotovihIgraca;

	// lista igraca koji ce se pretvarati u listu gotovih igraca
	private static ArrayList<Igrac> listaIgraca;

	// Igrac igrac = blabla
	// GotovIgrac gIgrac = igrac.napraviGotovogIgraca();

	public Igrac() {

	}

	public Igrac(String ime, String prezime, String pozicija, ArrayList<StatistickeKategorije> listaSKategorija) {
		super();
		this.ime = ime;
		this.prezime = prezime;
		this.pozicija = pozicija;
		this.listaSKategorija = listaSKategorija;
		this.proseciSKategorija = null;
		this.brojacMeceva = 0;
		Igrac.listaIgraca = new ArrayList<>();
		// Igrac.listaGotovihIgraca = new ArrayList<>();
	}

	public long getBrojacMeceva() {
		return brojacMeceva;
	}

	public GotovIgrac getGotovIgrac() {
		return gotovIgrac;
	}

	public static ArrayList<Igrac> getListaIgraca() {
		return listaIgraca;
	}

	public String getIme() {
		return ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public String getPozicija() {
		return pozicija;
	}

	public void setPozicija(String pozicija) {
		this.pozicija = pozicija;
	}

	public ArrayList<StatistickeKategorije> getListaSKategorija() {
		return listaSKategorija;
	}

	public void setListaSKategorija(ArrayList<StatistickeKategorije> listaSKategorija) {
		this.listaSKategorija = listaSKategorija;
	}

	public StatistickeKategorije getProseciSKategorija() {
		return proseciSKategorija;
	}

	public void setProseciSKategorija(StatistickeKategorije proseciSKategorija) {
		this.proseciSKategorija = proseciSKategorija;
	}

	@Override
	public String toString() {
		return "Igrac [ime=" + ime + ", prezime=" + prezime + ", pozicija=" + pozicija + ", listaSKategorija="
				+ listaSKategorija + ", proseciSKategorija=" + proseciSKategorija + ", brojacMeceva=" + brojacMeceva
				+ ", gotovIgrac=" + gotovIgrac + "]";
	}

	private double getFTAprosek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double prosek = 0.0;
		double brojac = 0.0;
		double ukupno = 0.0;
		for (StatistickeKategorije stat : listaSKategorija) {
			ukupno += stat.getFta();
			brojac++;
		}
		if (brojac != 0)
			prosek = ukupno / brojac;

		return prosek;
	}

	private double getFTMprosek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double prosek = 0.0;
		double brojac = 0.0;
		double ukupno = 0.0;
		for (StatistickeKategorije stat : listaSKategorija) {
			ukupno += stat.getFtm();
			brojac++;
		}
		if (brojac != 0)
			prosek = ukupno / brojac;

		return prosek;
	}

	public double getFTprocenat() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double procenat = 0.0;
		double FTMprosek = getFTMprosek();
		double FTAprosek = getFTAprosek();

		if (FTAprosek != 0)
			procenat = (FTMprosek / FTAprosek) * 100;

		return procenat;
	}

	private double get_2PMprosek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double prosek = 0.0;
		double brojac = 0.0;
		double ukupno = 0.0;
		for (StatistickeKategorije stat : listaSKategorija) {
			ukupno += stat.get_2pm();
			brojac++;
		}
		if (brojac != 0)
			prosek = ukupno / brojac;

		return prosek;
	}

	private double get_2PAprosek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double prosek = 0.0;
		double brojac = 0.0;
		double ukupno = 0.0;
		for (StatistickeKategorije stat : listaSKategorija) {
			ukupno += stat.get_2pa();
			brojac++;
		}
		if (brojac != 0)
			prosek = ukupno / brojac;

		return prosek;
	}

	public double get2Pprocenat() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double procenat = 0.0;
		double _2PMprosek = get_2PMprosek();
		double _2PAprosek = get_2PAprosek();

		if (_2PAprosek != 0)
			procenat = (_2PMprosek / _2PAprosek) * 100;

		return procenat;
	}

	private double get_3PMprosek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double prosek = 0.0;
		double brojac = 0.0;
		double ukupno = 0.0;
		for (StatistickeKategorije stat : listaSKategorija) {
			ukupno += stat.get_3pm();
			brojac++;
		}
		if (brojac != 0)
			prosek = ukupno / brojac;

		return prosek;
	}

	private double get_3PAprosek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double prosek = 0.0;
		double brojac = 0.0;
		double ukupno = 0.0;
		for (StatistickeKategorije stat : listaSKategorija) {
			ukupno += stat.get_3pa();
			brojac++;
		}
		if (brojac != 0)
			prosek = ukupno / brojac;

		return prosek;
	}

	public double get3Pprocenat() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double procenat = 0.0;
		double _3PMprosek = get_3PMprosek();
		double _3PAprosek = get_3PAprosek();

		if (_3PAprosek != 0)
			procenat = (_3PMprosek / _3PAprosek) * 100;

		return procenat;
	}

	public double getRebProsek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;
		long brojac = 0;

		for (StatistickeKategorije stat : listaSKategorija) {
			rezultat += stat.getReb();
			brojac++;
		}
		if (brojac != 0)
			rezultat = rezultat / brojac;

		return rezultat;
	}

	public double getBlkProsek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;
		long brojac = 0;

		for (StatistickeKategorije stat : listaSKategorija) {
			rezultat += stat.getBlk();
			brojac++;
		}
		if (brojac != 0)
			rezultat = rezultat / brojac;

		return rezultat;
	}

	public double getAstProsek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;
		long brojac = 0;

		for (StatistickeKategorije stat : listaSKategorija) {
			rezultat += stat.getAst();
			brojac++;
		}
		if (brojac != 0)
			rezultat = rezultat / brojac;

		return rezultat;
	}

	public double getStlProsek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;
		long brojac = 0;

		for (StatistickeKategorije stat : listaSKategorija) {
			rezultat += stat.getStl();
			brojac++;
		}
		if (brojac != 0)
			rezultat = rezultat / brojac;

		return rezultat;
	}

	public double getTovProsek() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;
		long brojac = 0;

		for (StatistickeKategorije stat : listaSKategorija) {
			rezultat += stat.getTov();
			brojac++;
		}
		if (brojac != 0)
			rezultat = rezultat / brojac;

		return rezultat;
	}

	public double getPoints() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;

		// FTM + 2*2PM + 3*3PM ---> prosecne vrednosti svake vrednosti
		rezultat = getFTMprosek() + 2 * get_2PMprosek() + 3 * get_3PMprosek();

		return rezultat;
	}

	public double getVal() {
		if (listaSKategorija.isEmpty())
			return 0.0;
		// (FTM + 2x2PM + 3x3PM + REB + BLK + AST + STL) - (FTA-FTM + 2PA-2PM + 3PA-3PM
		// + TOV)

		double rezultat = 0.0;

		rezultat = (getFTMprosek() + 2 * get_2PMprosek() + 3 * get_3PMprosek() + getRebProsek() + getBlkProsek()
				+ getAstProsek() + getStlProsek())
				- ((getFTAprosek() - getFTMprosek() + get_2PAprosek() - get_2PMprosek() + get_3PAprosek()
						- get_3PMprosek()));

		return rezultat;
	}

	public double getEFGprocenat() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		// ▪ (2PM + 3PM + 0,5 * 3PM) / (2PA + 3PA) * 100
		double rezultat = 0.0;

		rezultat = (get_2PMprosek() + get_3PMprosek() + 0.5 * get_3PMprosek()) / (get_2PAprosek() + get_3PAprosek())
				* 100;

		return rezultat;
	}

	public double getTSprocenat() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;
		// PTS / (2 * (2PA + 3PA +0,475 * FTA)) * 100
		rezultat = getPoints() / (2 * (get_2PAprosek() + get_3PAprosek() + 0.475 * getFTAprosek())) * 100;

		return rezultat;
	}

	public double getHAST() {
		if (listaSKategorija.isEmpty())
			return 0.0;

		double rezultat = 0.0;

		// AST / (2PA + 3PA + 0,475 * FTA + AST + TOV) * 100
		rezultat = getAstProsek()
				/ (get_2PAprosek() + get_3PAprosek() + 0.475 * getFTAprosek() + getAstProsek() + getTovProsek()) * 100;

		return rezultat;
	}

	private boolean postojiLiIgrac(String ime, String prezima) {
		boolean postojiIgrac = false;
		if (listaIgraca != null) {
			for (Igrac postojećiIgrac : listaIgraca) {
				if (postojećiIgrac.getIme().equals(ime) && postojećiIgrac.getPrezime().equals(prezime)) {
					postojiIgrac = true;
					break; 
				}
			}
		}

		return postojiIgrac;
	}

	private void povecajBrojacMeceva() {
		brojacMeceva++;
	}

	public static String[] razdvojiImePrezime(String imePrezime) {
		String[] rezultat = new String[2];

		// Pronalazi poziciju na kojoj počinje prezime (pretpostavljamo da se prezime
		// sastoji samo od velikih slova)
		int pozicijaPrezimena = 0;
		for (int i = 1; i < imePrezime.length(); i++) {
			if (Character.isUpperCase(imePrezime.charAt(i))) {
				pozicijaPrezimena = i;
				break;
			}
		}

		// Razdvoji ime i prezime
		rezultat[0] = imePrezime.substring(0, pozicijaPrezimena);
		rezultat[1] = imePrezime.substring(pozicijaPrezimena);

		return rezultat;
	}

	public void ucitajFajl(String csvFajl) {
		String delimiter = ",";
		Igrac igrac = null;

		try {
			File fajl = new File(csvFajl);
			FileReader fr = new FileReader(fajl);
			BufferedReader br = new BufferedReader(fr);
			String linija = "";
			String[] tempNiz;
			while ((linija = br.readLine()) != null) {
				tempNiz = linija.split(delimiter);

				String imePrezime = tempNiz[0];
				String[] delovi = imePrezime.split(" ", 2);

				String ime = delovi[0];
				String prezime = (delovi.length > 1) ? delovi[1] : "";

				String pozicija = tempNiz[1];
				String[] kategorijeNiz = tempNiz[2].split("");

				double ftm = 0.0;
				double fta = 0.0;
				double _2pm = 0.0;
				double _2pa = 0.0;
				double _3pm = 0.0;
				double _3pa = 0.0;
				double reb = 0.0;
				double blk = 0.0;
				double ast = 0.0;
				double stl = 0.0;
				double tov = 0.0;

				try {
					ftm = Double.parseDouble(kategorijeNiz[0]);
					fta = Double.parseDouble(kategorijeNiz[1]);
					_2pm = Double.parseDouble(kategorijeNiz[2]);
					_2pa = Double.parseDouble(kategorijeNiz[3]);
					_3pm = Double.parseDouble(kategorijeNiz[4]);
					_3pa = Double.parseDouble(kategorijeNiz[5]);
					reb = Double.parseDouble(kategorijeNiz[6]);
					blk = Double.parseDouble(kategorijeNiz[7]);
					ast = Double.parseDouble(kategorijeNiz[8]);
					stl = Double.parseDouble(kategorijeNiz[9]);
					tov = Double.parseDouble(kategorijeNiz[10]);
				} catch (NumberFormatException e) {
					fta = 0.0;

				}

				StatistickeKategorije statKategorije = new StatistickeKategorije(ftm, fta, _2pm, _2pa, _3pm, _3pa, reb,
						blk, ast, stl, tov);
				if (postojiLiIgrac(ime, prezime)) {
					dodajStatistikuIgracu(getListaIgraca(), ime, prezime, statKategorije);
					// Ažuriraj brojač mečeva za igrača
					igrac.povecajBrojacMeceva();
				} else {
					if (this.listaSKategorija == null) {
					    this.listaSKategorija = new ArrayList<>(); // Inicijalizacija liste ako je null
					}
					this.listaSKategorija.add(statKategorije);
					igrac = new Igrac(ime, prezime, pozicija, listaSKategorija);
					igrac.povecajBrojacMeceva(); // Povećaj brojač mečeva za novog igrača
					listaIgraca.add(igrac);
				}
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	private void dodajStatistikuIgracu(ArrayList<Igrac> listaIgraca, String ime, String prezime,
			StatistickeKategorije novaStatistika) {
		for (Igrac igrac : listaIgraca) {
			if (igrac.getIme().equals(ime) && igrac.getPrezime().equals(prezime)) {
				igrac.getListaSKategorija().add(novaStatistika);
				brojacMeceva++;

				break;
			}
		}
	}

	public String pronadjiIgracaIPrikaziDetalje(String ime, String prezime, ArrayList<GotovIgrac> listaGotovihIgraca) {
		String rezultat = "";

		for (GotovIgrac gotovIgrac : listaGotovihIgraca) {
			if (gotovIgrac.getIme().equals(ime) && gotovIgrac.getPrezime().equals(prezime)) {
				rezultat = gotovIgrac.toString();
				return rezultat;
			}
		}
		return "Igrač sa imenom " + ime + " i prezimenom " + prezime + " nije pronađen.";
	}

	public GotovIgrac napraviGotovogIgraca(Igrac igrac) {
		GotovIgrac gotovIgrac;
		/*
		 * public GotovIgrac(String ime, String prezime, long brojacMeceva, double
		 * fTAprosek, double fTMprosek, double fTprocenat, double _2pAprosek, double
		 * _2pMprosek, double _2Pprocenat, double _3pAprosek, double _3pMprosek, double
		 * _3Pprocenat, double pTSprosek, double rEBprosek, double bLKprosek, double
		 * aSTprosek, double sTLprosek, double tCVprosek, double vAL, double
		 * eFGprocenat, double tSprocenat, double hASTprocenat)
		 */

		gotovIgrac = new GotovIgrac(ime, prezime, brojacMeceva, getFTAprosek(), getFTMprosek(), getFTprocenat(),
				get_2PAprosek(), get_2PMprosek(), get2Pprocenat(), get_3PAprosek(), get_3PMprosek(), get3Pprocenat(),
				getPoints(), getRebProsek(), getBlkProsek(), getAstProsek(), getStlProsek(), getTovProsek(), getVal(),
				getEFGprocenat(), getTSprocenat(), getHAST());

		return gotovIgrac;
	}

	public ArrayList<GotovIgrac> pravljenjeListeGotovihIgraca(ArrayList<Igrac> listaIgraca) {
		ArrayList<GotovIgrac> listaGotovihIgraca = new ArrayList<>();

		for (Igrac igrac : listaIgraca) {
			// Pravite GotovIgrac objekat koristeći podatke iz trenutnog Igrac objekta
			GotovIgrac gotovIgrac = igrac.napraviGotovogIgraca(igrac); // Ovo će zavisiti od implementacije vaše klase
			listaGotovihIgraca.add(gotovIgrac);
		}

		return listaGotovihIgraca;
	}

}
