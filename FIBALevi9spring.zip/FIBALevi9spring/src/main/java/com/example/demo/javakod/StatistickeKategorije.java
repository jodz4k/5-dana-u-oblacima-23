package com.example.demo.javakod;

public class StatistickeKategorije {
	private double ftm, fta, _2pm, _2pa, _3pm, _3pa, reb, blk, ast, stl, tov;

	public StatistickeKategorije(double ftm, double fta, double _2pm, double _2pa, double _3pm, double _3pa, double reb,
			double blk, double ast, double stl, double tov) {
		super();
		this.ftm = ftm;
		this.fta = fta;
		this._2pm = _2pm;
		this._2pa = _2pa;
		this._3pm = _3pm;
		this._3pa = _3pa;
		this.reb = reb;
		this.blk = blk;
		this.ast = ast;
		this.stl = stl;
		this.tov = tov;
	}

	public double getFtm() {
		return ftm;
	}

	public double getFta() {
		return fta;
	}

	public double get_2pm() {
		return _2pm;
	}

	public double get_2pa() {
		return _2pa;
	}

	public double get_3pm() {
		return _3pm;
	}

	public double get_3pa() {
		return _3pa;
	}

	public double getReb() {
		return reb;
	}

	public double getBlk() {
		return blk;
	}

	public double getAst() {
		return ast;
	}

	public double getStl() {
		return stl;
	}

	public double getTov() {
		return tov;
	}

	@Override
	public String toString() {
		return " " + ftm + " " + fta + " " + _2pm + " " + _2pa + " "
				+ _3pm + " " + _3pa + " " + reb + " " + blk + " " + ast + " " + stl + " "
				+ tov;
	}

	

}
