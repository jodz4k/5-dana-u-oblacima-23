package com.example.demo.javakod;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;



@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@RestController
public class IgraciKontroler {
	
	
	public static void main(String[] args) {
		SpringApplication.run(IgraciKontroler.class, args);
	}
	private Igrac igrac = new Igrac();
	
	 @GetMapping("/{imePrezime}")
	    public List<String> getPlayerInfo(@PathVariable String imePrezime) {
		 
		 	String [] imePrezimeNiz = Igrac.razdvojiImePrezime(imePrezime);
		 	String ime = imePrezimeNiz[0];
		 	String prezime = imePrezimeNiz[1];
		 	
		 	
		 	/*
		 	 * --------------------------ideja jeste da se ovde ubaci full path----------------------------- 
		 	 */
		 	igrac.ucitajFajl("C:\\1 JovanFKs\\dogadjaji\\5 dana u oblacima\\Eliminacije\\L9HomeworkChallengePlayersInput.csv");
		 	ArrayList<Igrac> listaIgraca = Igrac.getListaIgraca();
		 	ArrayList<GotovIgrac> lista = igrac.pravljenjeListeGotovihIgraca(listaIgraca);
		 	
		 	String ispis = igrac.pronadjiIgracaIPrikaziDetalje(ime, prezime, lista);

	        
			return List.of(ispis);
		}

}
