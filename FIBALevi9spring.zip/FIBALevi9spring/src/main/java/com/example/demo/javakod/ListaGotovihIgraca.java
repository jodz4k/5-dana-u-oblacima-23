package com.example.demo.javakod;

import java.util.ArrayList;

public class ListaGotovihIgraca {
	private ArrayList<GotovIgrac> listaGotovihIgraca;

	public ListaGotovihIgraca() {
	}
	
	public ListaGotovihIgraca(ArrayList<GotovIgrac> listaGotovihIgraca) {
		this.listaGotovihIgraca = listaGotovihIgraca;
	}

	public ArrayList<GotovIgrac> getListaGotovihIgraca() {
		return listaGotovihIgraca;
	}

	public void setListaGotovihIgraca(ArrayList<GotovIgrac> listaGotovihIgraca) {
		this.listaGotovihIgraca = listaGotovihIgraca;
	}

	@Override
	public String toString() {
		return "ListaGotovihIgraca: " + listaGotovihIgraca;
	}

	public GotovIgrac pronadjiIgraca(String ime, String prezime) {
		for (GotovIgrac igrac : listaGotovihIgraca) {
			if (igrac.getIme().equals(ime) && igrac.getPrezime().equals(prezime)) {
				return igrac;
			}
		}
		return null; // Vraća null ako igrač nije pronađen
	}
	
	public void dodajIgraca(GotovIgrac igrac) {
		listaGotovihIgraca.add(igrac);
	}

}
