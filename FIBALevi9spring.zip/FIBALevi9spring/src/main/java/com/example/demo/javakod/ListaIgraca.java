package com.example.demo.javakod;

import java.util.ArrayList;

public class ListaIgraca {
	
	private ArrayList<Igrac> igraci;

	public ListaIgraca(ArrayList<Igrac> igraci) {
		super();
		this.igraci = igraci;
	}

	public ArrayList<Igrac> getIgraci() {
		return igraci;
	}

	public void setIgraci(ArrayList<Igrac> igraci) {
		this.igraci = igraci;
	}

	@Override
	public String toString() {
		return "ListaIgraca:" + igraci;
	}

}
