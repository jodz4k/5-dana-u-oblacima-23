package com.example.demo.javakod;

public class GotovIgrac {

	private String ime, prezime;
	private long brojacMeceva;
	private double FTAprosek, FTMprosek, FTprocenat;
	private double _2PAprosek, _2PMprosek, _2Pprocenat;
	private double _3PAprosek, _3PMprosek, _3Pprocenat;
	private double PTSprosek, REBprosek, BLKprosek, ASTprosek, STLprosek, TCVprosek;
	private double VAL, eFGprocenat, TSprocenat, hASTprocenat;

	public GotovIgrac(String ime, String prezime, long brojacMeceva, double fTAprosek, double fTMprosek,
			double fTprocenat, double _2pAprosek, double _2pMprosek, double _2Pprocenat, double _3pAprosek,
			double _3pMprosek, double _3Pprocenat, double pTSprosek, double rEBprosek, double bLKprosek,
			double aSTprosek, double sTLprosek, double tOVprosek, double vAL, double eFGprocenat, double tSprocenat,
			double hASTprocenat) {
		this.ime = ime;
		this.prezime = prezime;
		this.brojacMeceva = brojacMeceva;
		FTAprosek = fTAprosek;
		FTMprosek = fTMprosek;
		FTprocenat = fTprocenat;
		_2PAprosek = _2pAprosek;
		_2PMprosek = _2pMprosek;
		this._2Pprocenat = _2Pprocenat;
		_3PAprosek = _3pAprosek;
		_3PMprosek = _3pMprosek;
		this._3Pprocenat = _3Pprocenat;
		PTSprosek = pTSprosek;
		REBprosek = rEBprosek;
		BLKprosek = bLKprosek;
		ASTprosek = aSTprosek;
		STLprosek = sTLprosek;
		TCVprosek = tOVprosek;
		VAL = vAL;
		this.eFGprocenat = eFGprocenat;
		TSprocenat = tSprocenat;
		this.hASTprocenat = hASTprocenat;
	}

	public String getIme() {
		return ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public long getBrojacMeceva() {
		return brojacMeceva;
	}

	public double getFTAprosek() {
		return FTAprosek;
	}

	public double getFTMprosek() {
		return FTMprosek;
	}

	public double getFTprocenat() {
		return FTprocenat;
	}

	public double get_2PAprosek() {
		return _2PAprosek;
	}

	public double get_2PMprosek() {
		return _2PMprosek;
	}

	public double get_2Pprocenat() {
		return _2Pprocenat;
	}

	public double get_3PAprosek() {
		return _3PAprosek;
	}

	public double get_3PMprosek() {
		return _3PMprosek;
	}

	public double get_3Pprocenat() {
		return _3Pprocenat;
	}

	public double getPTSprosek() {
		return PTSprosek;
	}

	public double getREBprosek() {
		return REBprosek;
	}

	public double getBLKprosek() {
		return BLKprosek;
	}

	public double getASTprosek() {
		return ASTprosek;
	}

	public double getSTLprosek() {
		return STLprosek;
	}

	public double getTOVprosek() {
		return TCVprosek;
	}

	public double getVAL() {
		return VAL;
	}

	public double geteFGprocenat() {
		return eFGprocenat;
	}

	public double getTSprocenat() {
		return TSprocenat;
	}

	public double gethASTprocenat() {
		return hASTprocenat;
	}

	@Override
	public String toString() {
		return "{\n" +
		        "\n" +
		        "\"playerName\": \"" + getIme() + " " + getPrezime() + "\",\n" +
		        "\"gamesPlayed\": " + getBrojacMeceva() + ",\n" +
		        "\"traditional\": {\n" +
		        "  \"freeThrows\": {\n" +
		        "    \"attempts\": " + getFTAprosek() + ",\n" +
		        "    \"made\": " + getFTMprosek() + ",\n" +
		        "    \"shootingPercentage\": " + getFTprocenat() + "\n" +
		        "  },\n" +
		        "  \"twoPoints\": {\n" +
		        "    \"attempts\": " + get_2PAprosek() + ",\n" +
		        "    \"made\": " + get_2PMprosek() + ",\n" +
		        "    \"shootingPercentage\": " + get_2Pprocenat() + "\n" +
		        "  },\n" +
		        "  \"threePoints\": {\n" +
		        "    \"attempts\": " + get_3PAprosek() + ",\n" +
		        "    \"made\": " + get_3PMprosek() + ",\n" +
		        "    \"shootingPercentage\": " + get_3Pprocenat() + "\n" +
		        "  },\n" +
		        "  \"points\": " + getPTSprosek() + ",\n" +
		        "  \"rebounds\": " + getREBprosek() + ",\n" +
		        "  \"blocks\": " + getBLKprosek() + ",\n" +
		        "  \"assists\": " + getASTprosek() + ",\n" +
		        "  \"steals\": " + getSTLprosek() + ",\n" +
		        "  \"turnovers\": " + getTOVprosek() + "\n" +
		        "},\n" +
		        "\"advanced\": {\n" +
		        "  \"valorization\": " + getVAL() + ",\n" +
		        "  \"effectiveFieldGoalPercentage\": " + geteFGprocenat() + ",\n" +
		        "  \"trueShootingPercentage\": " + getTSprocenat() + ",\n" +
		        "  \"hollingerAssistRatio\": " + gethASTprocenat() + "\n" +
		        "}\n" +
		        "}";

	}
}
